title: 使用Dockerfile构建Centos7镜像/php镜像/wordpress
date: '2019-08-24 23:53:26'
updated: '2019-08-25 11:34:55'
tags: [Docker]
permalink: /articles/2019/08/24/1566662006622.html
---

本实验在OSX Parallels Desktop Centos7中验证,环境准备遇到的问题：
1.[不能root用户登录，参考](https://blog.csdn.net/LCYong_/article/details/60466601) ,  [sudo su](https://linux.cn/article-8404-1.html)
2.[yum安装出现/var/run/yum.pid已被占用，删除该文件即可，参考](https://blog.csdn.net/LCYong_/article/details/60466601)
3.[安装git 参考 ](https://git-scm.com/book/zh/v1/%E8%B5%B7%E6%AD%A5-%E5%AE%89%E8%A3%85-Git)
4.克隆资源 [https://gitee.com/dockerf/docker-training](https://gitee.com/dockerf/docker-training)  
https://csphere.cn/
5.[Centos Docker安装](https://www.runoob.com/docker/centos-docker-install.html)

>Docker体积小的原因 ：不包含父镜像的大小 

- Centos
- php-fm
- mysql
- wordpress
  

## 操作步骤
> 查看命令使用方式 docker help build
```
## 构建基础镜像
## docker build -t registry_url/namespace/fubin/centos:7.1  ./path
docker build -t csphere/centos:7.1 .
## 运行  端口 -P容器重启后宿主机端口会发生变化和 -p端口不变
docker run -d -p 2222:22 --name base  csphere/centos:7.1 


## 构建中间镜像 php-fm
docker build -t csphere/php-fpm:5.4 .
## 
docker run -d -p 8080:80  --name website  csphere/php-fpm:5.4
## 检查php环境
http://127.0.0.1:8080/info.php
## 进入交互式模式 attach会挂掉
docker exec -it  website  /bin/bash
## supervisor 工具查看进程状态
supervisorctl

## 构建中间镜像mysql，如果这个镜像想包含php的功能，FROM则可以使用php-fm镜像
docker build -t csphere/mysql:5.5 .
## start脚本 set -e 第一条脚本执行出错，则不会继续执行下面的命令

## 启动mysql5.5
docker run -d -p 3307:3306 --name dbserver scphere/mysql:5.5
##进入容器
docker exec -it dbserver /bin/bash
## 挂载volmue
docker run -d -p 3307:3306 -v ~/Documents/Projects/docker/docker-training/mysql/data:/var/lib/mysql --name dbserver csphere/mysql:5.5

## 构建服务wordpress
.dockerignore  忽略某文件
## 使用php-fm当作父镜像，ONBUILD指令起作用，把php文件拷贝到/app目录中
docker build -t csphere/wordpress:4.2 ./wordpress
## 启动 wordpress
docker run -d -p 80:80 --name wordpress -e WORDPRESS_DB_HOST=127.0.0.1 -e WORDPRESS_DB_USER=admin -e WORDPRESS_DB_PASSWORD=csphere2015 csphere/wordpress:4.2 
```






## Centos  Dockerfile  Demo

```
#
# MAINTAINER        Carson,C.J.Zeong <zcy@nicescale.com>
# DOCKER-VERSION    1.6.2
#
# Dockerizing CentOS7: Dockerfile for building CentOS images
#
FROM       centos:centos7.1.1503
MAINTAINER Carson,C.J.Zeong <zcy@nicescale.com>

ENV TZ "Asia/Shanghai"
ENV TERM xterm

ADD aliyun-mirror.repo /etc/yum.repos.d/CentOS-Base.repo
ADD aliyun-epel.repo /etc/yum.repos.d/epel.repo

RUN yum install -y curl wget tar bzip2 unzip vim-enhanced passwd sudo yum-utils hostname net-tools rsync man && \
    yum install -y gcc gcc-c++ git make automake cmake patch logrotate python-devel libpng-devel libjpeg-devel && \
    yum install -y --enablerepo=epel pwgen python-pip && \
    yum clean all

RUN pip install supervisor
ADD supervisord.conf /etc/supervisord.conf

RUN mkdir -p /etc/supervisor.conf.d && \
    mkdir -p /var/log/supervisor

EXPOSE 22

ENTRYPOINT ["/usr/bin/supervisord", "-n", "-c", "/etc/supervisord.conf"]
```

