title: '在Docker容器中部署静态网站 '
date: '2019-08-18 17:11:36'
updated: '2019-08-18 17:14:37'
tags: [Docker]
permalink: /articles/2019/08/18/1566119496434.html
---
- 设置容器的端口映射

	- 大写[-P] --publish-all=true `docker run -P -i -t ubuntu /bin/bash`

 	- 小写[-p] --publish=[]

- 指定容器端口 `docker run -p 80 -i -t ubuntu /bin/bash`

- 指定主机端口和容器端口 `docker run -p 8080:80 -i -t ubuntu /bin/bash`

- 指定ip和容器端口 `docker run -p 0.0.0.0:80 -i -t ubuntu /bin/bash`

- 指定ip宿主机端口，容器端口`docker run -p 0.0.0.0:8080:80 -i -t ubuntu /bin/bash`

- 拉取centos容器 docker search centos ，docker pull centos

- 启动容器并把端口映射为9999：`docker run -i -t -d -p 9999:80 --name web centos /bin/bash`

- 安装必要软件，如wget,curl `yum install -y wget `

- 安装nginx : yum方法安装无法安装成功，需要安装nginx源 `yum install -y nginx`

- `rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm`

- yum源的资源路径在`/etc/yum/repos.d/nginx.repo`

- 外网访问http://localhost:9999,容器内访问http:://localhost:80

- 其他容器访问，通过docker inspect查看容器的ip ，端口任然使用80


> 附录

以下是Nginx的默认路径：

(1) Nginx配置路径：/etc/nginx/  
(2) PID目录：/var/run/[nginx.pid](https://www.centos.bz/tag/nginx-pid/)  
(3) 错误日志：/var/log/nginx/[error](https://www.centos.bz/tag/error/).log  
(4) 访问日志：/var/log/nginx/access.log  
(5) 默认站点目录：/usr/share/nginx/html

以下是Nginx常用命令
- 启动：nginx
- 测试配置是否正确 nginx -t
- 优雅重启 nginx -s reload
- 查看nginx进程 ps -ef | grep nginx
- 停止 nginx -s stop 或 kill -9 pid

