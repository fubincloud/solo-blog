title: JVM：《实战Java虚拟机》阅读笔记
date: '2019-08-17 20:50:15'
updated: '2019-08-27 00:37:13'
tags: [JVM]
permalink: /articles/2019/08/17/1566046215170.html
---
#  Java历史

##  依托于Java虚拟机的语言

	- Java
	
	- Ckojure - Kisp的方言
	
	- Jython - 将python运行在JVM上
	
	- Groovy - JVM上的脚本语言
	
	- Scala - 专注于高并发解决方案
	
	- Kotlin - 安卓开发首选

## Java发展史

	- 跨平台系统，Oak
	
	- Sun发布Java和HotJava产品
	
	- JDK1.0，运行环境和开发环境，核心api，用户界面api，发布技术，jvm，使用Classic虚拟机解释执行
	
	- JDK1.1 AWT，内部类，JDBC，RMI，反射，sun获得hotspot虚拟机
	
	- Jython创造，目前已经可以运行Django了
	
	- JDK1.2 兼容智能卡和小型消费设备，大型服务器系统，发布JSP/Servlet规范，Java分裂为J2EE,J2SE，J2ME，解释和编译混合执行
	
	- JDK1.3 Hotspot成为Java默认虚拟机
	
	- JDK1.4 Classic虚拟机淘汰
	
	- JDK1.5 改名5.0，范型，注解，自动装箱拆箱，枚举，可变长参数，增强foreach
	
	- JDK1.6 开源OpenJDK，Hotspot是它的默认虚拟机
	
	- 新语言Clojure出现
	
	- Oracle收购BEA，得到JRockit虚拟机
	
	- Scala：Twitter迁移大部分Ruby服务到Scala
	
	- Oracle收购Sun，准备规划整合Hotspot和JRockit虚拟机
	
	- JDK1.7发布，新垃圾回收器G1，64位压缩指针，NIO2.0，增加invokedynamic指令
	
	- JDK1.8 Lambda表达式
	
	- JDK1.9 Java模块化

##  [Java语言规范](https://docs.oracle.com/javase/specs/)

- 数字的表示

```java

//JDK1.7允许在数字中加加入下划线分割
int a = 0372;
int b = 0xDada_Cafe;
int c = 0x00_FF__00_FF;
long la = 01;
long lb = 0777L;
long lc = 0x100000000L;
long ld = 2_147_483_648L;
long le = 0xC0B0L;
float fa = 1e1f;
float fb = 2.f;
float fc = .3f;
float fd = 3.14f;
float fe = 6.022137e+23f;
double da = 1e1;
double db = 2.;
double dc = .3;
double dd = 0.0;
double de = 1e-9d;
double df = 1e137;
```

- 数据类型

	- 原始

		- 数字型：（byte 8bit ，short 16bit ，int 32bit，long 64bit）有符号，char 16bit 无符号，float 32bit，double 64bit

		- 布尔型：boolean ：true，false

	- 引用

##  [Java虚拟机规范](https://docs.oracle.com/javase/specs/index.html)

- 特性

	- 跨平台
	
	- 优秀的垃圾回收器
	
	- 可靠的即时编译器

- 内容

	- 虚拟机内部结构
	
	- 虚拟机执行的字节码类型和功能
	
	- Class文件结构
	
	- 类的装载，连接，初始化

- 整数在虚拟机中的表示

	- 在计算机中整数用补码表示，虚拟机也是
	
		- 概念：原码，反码，补码
	
			- 原码：1符号位 + 其余二进制数
			
			- 反码：符号位不变，其余取反
			
			- 补码：负数补码= 反码+1 ，正数补码= 原码

		- 补码好处：
			
			- 统一数字0的表示，原码很难确定无符号数字0
			
			- 简化整数的加减计算，正负数计算统一成加法。

```java

//-10在虚拟机的表示

// 0x80000000 为符号为1，其余是0的32位数字，得到i位数字，并把除i之外的其他位数设置为0，然后把i移到最右输出

int d = -10;

for(int i = 0; i<32;i++){

int t = (d & 0x80000000 >>> i) >>> (31-i);

System.out.print(t);

}

```

- 浮点型在虚拟机的表示

	- IEEE754定义的浮点数格式

		- 三部分：符号位 + 指数位 + 尾数位
		
		- float 32bit ：1符号位 + 8指数位 + 23尾数位 `s eeeeeeee mmmmmmmmmmmmmmmmmmmmmmm`

	- 浮点数-5 `1 10000001 0100000000000000000000`

		- 符号为 1 ，负数
	
		- 指数位 129
		
		- 尾数位(`实际上是24位`) ： e不全位0，前面加1=`1`0100000000000000000000 ,全为0，则附加0
	

	- 表示特殊数字
	
		- 正无穷
		
		- 负无穷
		
		- NaN
		
		- 最大浮点数
		
		- 最小规范化正浮点数
		
		- 最小正浮点数
		
		- 0
	

## 编译和调试虚拟机

- 作用

	- 得到一个debug版本，支持更多虚拟机参数
	
	- 用于虚拟机代码单步调试

- [centos7构建jdk8](http://hg.openjdk.java.net/jdk8u/jdk8u/raw-file/tip/README-builds.html)

	- 安装jdk版本控制系统[mercurial变幻莫测](https://www.mercurial-scm.org/release/centos7/RPMS/x86_64/),[download](https://mercurial.selenic.com/wiki/Download#Windows); centos :`yum install mercurial`

	- OSX安装:`brew install mercurial`

- 拉取源码：

```markdown

hg clone http://hg.openjdk.java.net/jdk8/jdk8 YourOpenJDK

cd YourOpenJDK

bash ./get_source.sh

```

# JVM基本结构

- Java虚拟机基本结构

- 角色：字节码执行引擎，垃圾回收系统，`方法区，Java堆，直接内存`[共享]，类加载子系统，`PC寄存器(计数器)，本地方法栈，Java栈`[私有]

- 垃圾回收的工作重点：方法区，Java堆，直接内存

- 一个Java线程对应一个java栈

- 参数

- 程序参数：应用程序使用

- 虚拟机参数：虚拟机使用

- Java堆的结构

- 新生代 ： young

- from

- to

- eden ：对象创建的地方

- -------> young转换到tenured:`对象年龄`

- 老生代：tenured

- Xss Java虚拟机参数，栈空间大小

- 方法参数更多，调用层数越少

- [jclasslib工具](https://github.com/ingokegel/jclasslib) `1 Word 字 = 4 字节`

- 栈上分配：线程私有对象，直接分配在栈上，而不是Java堆上，对象在函数调用结束之后自行销毁，不需要经过垃圾回收器。

- 依赖`逃逸分析`和`标量替换`
