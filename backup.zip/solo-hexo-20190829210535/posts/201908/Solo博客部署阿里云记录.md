title: Solo博客部署阿里云记录
date: '2019-08-17 18:26:20'
updated: '2019-08-28 13:57:23'
tags: [Solo]
permalink: /articles/2019/08/17/1566037580555.html
---
# 数据库篇

```

create database solo default charset utf8mb4 collate utf8mb4_general_ci;


#启动
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=Lzslov123! -d mysql

docker run -p 3306:3306 --name solodb -v $PWD/conf:/etc/mysql/conf.d -v $PWD/logs:/logs -v $PWD/data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=password -d mysql

#进入容器
docker exec -it mysql bash
#登录mysql
mysql -u root -p
ALTER USER 'root'@'localhost' IDENTIFIED BY 'Lzslov123!';

#添加远程登录用户
CREATE USER 'liaozesong'@'%' IDENTIFIED WITH mysql_native_password BY 'Lzslov123!';
GRANT ALL PRIVILEGES ON *.* TO 'liaozesong'@'%';


-- 启动solo服务
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="xxxx" \
    --env JDBC_PASSWORD="xxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=80 --server_scheme=http --server_host=域名 --server_port=80

```


  
文件上传下载工具 ：xshell 下的rz sz  
https://blog.51cto.com/oldboy/588592  
  
  
Docker下的数据库备份：  
  
https://blog.csdn.net/MR1269427885/article/details/82978311  
  
```  
docker exec -i solodb bash <<'EOF'  
  
mkdir ~/$(date +%Y%m%d)  
  
## 备份指定数据库  
mysqldump --databases solo  -u用户名 -p密码 > /root/$(date +%Y%m%d)/solodb_$(date +%Y%m%d_%H%M%S).sql  
##mysqldump -u用户名 -p密码 > ~/$(date +%Y%m%d)/solodb_$(date +%Y%m%d_%H%M%S).sql  
  
# 备份所有数据库  
## mysqldump --no-defaults --events --all-databases -uroot -padmin > /backup/mysql/$(date +%Y%m%d)/all_$(date +%Y%m%d_%H%M%S).sql  
  
exit  
  
EOF  
  
docker  cp -a  solodb:/root/$(date +%Y%m%d)   /root/info/data/  
  
```

crontab定时任务 
```
## 定时任务
crontab -e

# 每天下午一点执行脚本 
0 13 * * * bash /backup/mysql.sh

##重启crond
service crond restart
```

### 服务器复制文件到本地

```
#!/bin/bash

filename=`date -v -0d +%Y-%m-%d`
## 远程拷贝
scp -r root@IP:服务器路径  ./${filename}
## 压缩
zip -r ${filename}.zip ${filename}
```

# 配置Blog二级域名篇

初步想法： 
使用 blog.fubincloud.cn 作为博客系统的域名
www.fubincloud.cn 单独做一个静态导航页面，部署在nginx中，nginx还可以放其他静态页面，比如极客时间的教程资源，方便随时浏览。



##    [docker+nginx+solo+mysql部署](https://hacpai.com/article/1556265895068)

docker网桥工具安装
yum install bridge-utils
brctl show 

- 建网络 docker network create -d bridge fubincloud

使用映射在磁盘上的数据卷，docker容器删除，数据卷不会删除。
```
docker run -p 3306:3306 --name solodb --network=fubincloud \
 -v $PWD/conf:/etc/mysql/conf.d \
 -v $PWD/logs:/logs \
 -v $PWD/data:/var/lib/mysql  -d mysql
```

重新设置solo应用的域名，端口
```
docker rm -f solo
docker run --detach --name solo --network=fubincloud \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="fubin" \
    --env JDBC_PASSWORD="fubin19910521" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://solodb:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=8080 --server_scheme=http --server_host=blog.fubincloud.cn --server_port=
```

nginx目录映射，容器启动
```
docker run -d --name fubin-proxy -p 80:80 --network=fubincloud -v $PWD/conf/nginx.conf:/etc/nginx/nginx.conf  -v $PWD/www:/usr/share/nginx/html -v $PWD/logs:/var/log/nginx nginx
## 一级域名和二级域名配置
    server {
    	listen 80;
    	server_name fubincloud.cn www.fubincloud.cn;
	## 注意这个目录是容器内的目录
	root /root/nginx/www/home;
	index  home.html;
	location ~* ^.+\.(jpg|jpeg|gif|png|ico|css|js|pdf|txt){
	## 注意这个目录是容器内的目录
    		root /www/home;
  	}
    }
    server {
	listen 80;
	server_name blog.fubincloud.cn;

	location / {
		proxy_pass http://blog;
		proxy_set_header Host      $http_host;
		proxy_set_header X_Real_IP $remote_addr;
	}

    }
```
> 静态网页拷贝 
scp  资源文件  root@ip:/root/service/nginx/www/home




