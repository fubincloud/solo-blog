title: Solo:MySQL设置和程序启动
date: '2019-08-17 18:26:20'
updated: '2019-08-24 14:24:59'
tags: [Solo]
permalink: /articles/2019/08/17/1566037580555.html
---
```

create database solo default charset utf8mb4 collate utf8mb4_general_ci;


#启动
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=Lzslov123! -d mysql
#进入容器
docker exec -it mysql bash
#登录mysql
mysql -u root -p
ALTER USER 'root'@'localhost' IDENTIFIED BY 'Lzslov123!';

#添加远程登录用户
CREATE USER 'liaozesong'@'%' IDENTIFIED WITH mysql_native_password BY 'Lzslov123!';
GRANT ALL PRIVILEGES ON *.* TO 'liaozesong'@'%';


-- 启动solo服务
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="xxxx" \
    --env JDBC_PASSWORD="xxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=80 --server_scheme=http --server_host=域名 --server_port=80

```
