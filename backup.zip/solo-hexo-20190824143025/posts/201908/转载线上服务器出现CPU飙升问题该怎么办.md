title: 《转载》 线上服务器出现 CPU 飙升问题该怎么办？
date: '2019-08-22 23:49:58'
updated: '2019-08-22 23:51:43'
tags: [Reprint]
permalink: /articles/2019/08/22/1566488998831.html
---
![](https://img.hacpai.com/bing/20180510.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

https://hacpai.com/article/1564653864931?r=88250#1564653966662

1.top查看占用cpu高的进程
2.top -p pid -H 查看进程中的线程
3.jstack -l -F pid 查看2步骤中列出来的进程中线程栈，拿到一些线程信息
4.如何检索：进程pid和线程中的对应关系，需要把2步骤的pid转化为十六进制
5.在线程栈文件中搜索 ：`cat jstack.dump | grep "nid=0x779" -C 10`
6.GC问题调参数，其他问题再分析
7.推荐诊断开源工具 ：[Arthas](https://github.com/alibaba/arthas/blob/master/site/src/site/sphinx/index.md)
