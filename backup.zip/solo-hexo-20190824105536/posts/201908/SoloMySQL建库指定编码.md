title: Solo:MySQL建库指定编码
date: '2019-08-17 18:26:20'
updated: '2019-08-17 18:26:20'
tags: [Solo]
permalink: /articles/2019/08/17/1566037580555.html
---
```
-- solo 建库
create database `solo` character set utf8mb4 collate utf8mb4_general_ci;

```
