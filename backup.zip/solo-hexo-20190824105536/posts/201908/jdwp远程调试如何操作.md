title: jdwp远程调试如何操作
date: '2019-08-17 21:34:54'
updated: '2019-08-17 21:34:54'
tags: [jdwp]
permalink: /articles/2019/08/17/1566048893918.html
---
（1）远程程序的配置在javaArgs加入参数-Xdebug -Xrunjdwp:transport=dt_socket,suspend=n,server=y,address=5555在快仓的后台（manager-ng）中，则是编辑wallemanagerd，在javaArgs加入上述参数。

（2）ecplise配置菜单：Debug -》 Debug confeguration弹窗：Remote Java Application双击Remote Java Application会生成监听当前模块的类应用Host：远程程序的ip地址Port：远程javaArgs公开的端口。单击Debug则开始远程监听调试，需要设置断点来看变量。
