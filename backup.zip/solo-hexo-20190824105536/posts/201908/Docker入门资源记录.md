title: Docker入门资源记录
date: '2019-08-17 18:37:59'
updated: '2019-08-18 15:03:35'
tags: [Docker]
permalink: /articles/2019/08/17/1566038279637.html
---
- [Docker练习教程](https://docker-curriculum.com/)

- [一个集成UNIX小程序的docker镜像:busybox](https://hub.docker.com/_/busybox/)

- [github](https://github.com/docker-library/busybox)

- docker部署webapp；后台运行，暴露端口 [外:内]

- docker镜像：版本指定

- 镜像分类：基础和子镜像，官方和用户镜像

- 创建自定义的镜像:[flask应用程序](https://github.com/prakhar1989/docker-curriculum.git)

- 通过Dockerfile构建自己的镜像

- Docker推送到云端共享给他人，使用公共Hub如[Docker官方Hub](https://hub.docker.com/) account:[`fubinh`](https://hub.docker.com/u/fubinh) ,[亚马逊AWS](https://aws.amazon.com/cn/ecr/)或者[自己创建私有镜像库](https://docs.docker.com/registry/deploying/)

- 多容器运行应用，[Python-Flask和Elasticsearch示例](https://github.com/prakhar1989/FoodTrucks)

- docker网路：桥接,创建自己的网络,隔离网络

- Docker Compose

- [Docker Machine](https://docs.docker.com/machine/) 在自己的计算机，云提供商和您自己的数据中心内创建Docker主机

- [Docker Compose](https://docs.docker.com/compose/) ：用于`定义和运行多容器Docker应用程序`的工具

- [Docker Swarm](https://docs.docker.com/swarm/) - Docker的本机群集解决方案

- [Kubernetes](https://kubernetes.io/) - Kubernetes是一个开源系统，用于自动化容器化应用程序的部署，扩展和管理。

- [Awesome Docker](https://github.com/veggiemonk/awesome-docker)

- [Docker课堂](https://training.play-with-docker.com/)

- 运维篇

- 研发篇

- [docker监控工具：lazydocker](https://github.com/jesseduffield/lazydocker)

```shell

## 前台运行

docker pull lazydocker

docker run -it -v /var/run/docker.sock:/var/run/docker.sock -v /opt/docker:/.config/jesseduffield/lazydocker lazyteam/lazydocker

```



- [官方文档](https://docs.docker.com/) ： 分为以下几大块内容

- 获取Docker

- 开始使用Docker

- 使用Docker进行开发

- 配置网络

- 管理应用程序数据

- 在生产中运行你的app

- Docker标准和合规性compliance

- Docker中的开源代码

- 文档归档(历史版本)

