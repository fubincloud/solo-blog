title: docker基础知识
date: '2019-08-18 15:05:12'
updated: '2019-08-25 13:33:52'
tags: [Docker]
permalink: /articles/2019/08/18/1566111912448.html
---
![](https://img.hacpai.com/bing/20190417.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 



## Docker的基本组成

Docker客户端/守护进程：C/S架构 本地/远程

Docker Image 镜像 ： 容器的基石，层叠的只读文件系统 bootfs -> rootfs(ubuntu) -> add app , 联合加载

Docker Container 容器 ： 通过镜像启动，启动和执行阶段，写时复制

Docker Registry仓库 ： 共有，私有，Docker Hub

> Docker实际上是运行在Linux之上的技术，在windows和OS X中需要运行在docker定制的虚拟机上。

## 容器的基本操作

- 启动容器 docker run IMAGE command arg `docker run ubuntu echo "hello world"`

- 启动交互式容器 docker run -i -t ubuntu /bin/bash

	- -i --interactive=true\false

	- -t --tty=true/false

- 查看容器 docker ps [-a][-l][-q]

- docker inspect containerid/name 查看容器配置

- 自定义容器名字 docker run --name container新名字 -i -t ubuntu /bin/bash

- 重新启动和停止容器 docker start/stop -i containerName

	- 停止所有容器 `docker stop $(docker ps -a -q)`

- 删除停止的容器或所有容器 docker rm container / `$(docker ps -a -q)`


### 守护形式运行容器演示

- 运行容器 docker run -i -t ubuntu /bin/bash

- 退出容器内部/实际上在后台运行 ctrl +p 或 ctrl + q

- 重新进入容器 docker attach 容器id

- 真正退出容器 exit

- 守护式容器启动一般方法演示 docker run --name dc1 -d ubuntu /bin/sh -c "while true;do echo hello world ;sleep 1;done"

### 查看容器日志

docker logs -tf --tail 10 dc1

查看容器中的进程

docker top containerName

在运行中容器内部启动新进程

docker exec [-d][-i][-t] 容器名 [command][args]

停止守护式容器

docker stop 容器名

docker kill 容器名

## 镜像操作

docker images  [-a --all] [-f filter] [--no-trunc imageid不截断][-q --quiet 只显示id]
	- repository,tag,image id,created,大小
	- <none>中间层镜像
查看镜像详细信息：docker inspect  imageid/仓库+tag
删除镜像 docker rmi  imageid/仓库+tag
删除所有镜像 docker rmi $(docker images -q  ubuntu)

查找镜像
	- Docker Hub
	- docker search  imagesName [--automated=false][--no-trunc][-s --stars 最低star数]
拉取镜像
	- docker pull  仓库+tag [不指定则下载lastest]

> 国内docker镜像服务器加速镜像下载
使用 --registry-mirror选项,修改完毕后重启docker守护进程 service docker restart
	- /etc/default/docker 添加 DOCKER_OPTS = "--registry-mirror=http://www.daocloud.io"
推送镜像
	- docker push imageName:tag


## 构建镜像

- 通过容器构建 ：docker commit  [-a --author][-m --message] [-p --pause=true] 容器名 
	- 把应用打成新的镜像  `docker commit -a "fubinh" -m "nginx web server test"  nginx_web_test fubinh/nginx_web_test`
	- 用新镜像启动容器：`docker run -d --name nginx_web -p 80 fubinh/nginx_web_test nginx -g "daemon off;"`


- 通过Dockerfile构建镜像 ： docker build --force-rm= false --no-cache=false --pull=false [-q,--quiet=false],--rm=true,[-t,--tag="ImageName"]
```python
FROM centos
MAINTAINER fubinh "fubincloud@gmail.com"
RUN rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
RUN yum install -y nginx
EXPOSE 80
```
开始根据Dockerfile文件构建 ：`docker build -t='fubinh/nginx_web_test2'  .`    注意这里有一个点，代表Dockerfile文件在当前文件夹


## Docker的C/S模式 - Remote API

- https://docs.docker.com/develop/sdk/

连接方式

- unix:///var/run/docker.sock

- tcp://host:port

- fd://socketfd

> 客户端和服务端可以部署在不同的机器上，可以通过以上三种方式调用服务端接口

## Docker守护进程配置

启动选项

	运行相关：[-D --debug][-e --exec-driver="native"][-g --graph="/var/lib/docker"]
	
	服务器连接相关 [-G ,-H]...
	
	存储相关 [-S ]...
	
	Registry相关
	
	网络设置相关
	
	docker启动配置文件 ：linux[/etc/defaults/docker]

## Docker的远程访问

Docker客户端和服务端部署在两台机器上

	-H 选项
	
	DOCKER_HOST环境变量简化远程访问配置

## Dockerfile 指令

- FROM 基础镜像

- MAINTAINER 维护者

- RUN 运行指令 ，`镜像构建过程中`执行

- EXPOSE 暴露端口

- CMD `容器运行时`执行的指令（会覆盖我们在命令行docker run指定的命令）

- exec模式 CMD[ "executable","param1","param2"]

- shell 模式 CMD command param1 param2

- CMD["param1","param2"] 作为ENTRYPOINT指令默认参数, 启动容器时后面带的命令会把cmd命令覆盖

- ENTRYPOINT ：和cmd唯一区别是不会覆盖docker run的指定命令,`只有最后一条生效`，启动容器后面的命令覆盖不了entrypoint带的命令，可以在docker run 后面带--entrypoint参数覆盖

- ADD [src dest] 文件和目录复制到使用Dockerfile构建的镜像中,包含了`tar解压功能`,可以带远程`链接地址`

- COPY 单纯复制，推荐使用COPY而不是ADD

- VOLUME["/data"] 可以存在于一个或者多个容器的特定目录，这个目录可以绕过联合文件系统，提供共享数据和数据持久化的功能

- WORKDIR /path/to/workdir 从镜像创建一个新容器时，在容器内部设置工作目录，cmd和entrypoint指定的命令都会在这个目录下执行，通常使用绝对路径，如果使用相对路径，会传递下去。

- ENV key=value 环境变量，构建和运行过程中有效

- USER daemon 以什么用户来运行,默认root用户

- USER user / uid / user:group / uid:gid / user:gid / uid:group

- ONBUILD 镜像触发器 ，当一个镜像被其他镜像作为基础镜像时执行，在构建过程中插入指令 ，比如复制宿主机上的页面替代nginx默认页面，当构建新的镜像时，这个替换才会生效。

## 镜像的构建过程 
	- 使用缓存和不使用缓存(--no-cache)
	- 中间层镜像调试
	- 查看构建过程 docker history images

## Docker 网络

### 基础

- docker0 网桥 属于 ISO七层模型中的数据链路层

- 修改docker0的ip ：ifconfig docker0 192.168.21.110 netmask 255.255.255.0

- 自定义虚拟网桥

### 容器互联

- 允许所有容器互联 默认 --icc=true

- --link container:别名 启动时docker会自动修改容器的ip地址和hosts文件的映射

- 拒绝容器间的连接 --icc=false (全部拒绝)

- 允许特定的容器间的连接 --icc=false --iptables=true（控制网络访问的组件，配置了--link的可以访问）

iptables -L -n

### 容器与外部网络连接

--ip_forward=true ： 是否允许转发流量

iptables ：与Linux内核集成的包过滤防火墙系统 表table。链filter（input，forward，output），规则rule

允许端口映射访问

限制IP访问容器

> 学习iptables的设置

## 容器的数据管理

### 数据卷

变化的数据需要持久化，数据需要在容器间共享。可以绕过联合文件系统UFS

添加数据卷：docker run -v ~/container_data:/data -it ubuntu /bin/bash

为数据卷添加只读权限：docker run -v ~/container_data:/data:ro -it ubuntu /bin/bash

Dockerfile创建数据卷： VOLUME["/data/d1"."/data/d2"]，本地的映射目录由docker自动创建，使用docker inspect containerid 查看，相同dockerfile创建的不同容器数据卷是不同的

### 数据卷容器

实现数据的共享：命名的容器挂在数据卷，其他容器通过挂载这个容器实现数据共享，挂载数据卷的容器，就叫做数据卷容器。

docker run --volumes-from 挂载了数据卷的容器名

查看配置过滤信息：docker inspect --format="{{.Volumes}}" 容器名

如果数据卷容器删除了，不影响其他容器数据的使用，容器数据卷挂载可以传递。

>如果一个数据卷还在被容器使用，那么他就会一直存在。

### 数据卷的备份和还原

备份方法：新建一个用于数据备份的容器

docker run --volumes-from 容器名 -v /backup[本地目录]:/backup[容器目录] --name containerName[备份容器名] ubuntu[镜像] tar cvf /backup/dvt5.tar[压缩后的名字] /datavolume1[需要备份的目录]

还原和备份的思路一致，把压缩命令替换成解压缩命令

## 容器的跨主机连接

- 使用网桥实现跨主机容器连接

安装网桥管理工具 bridge-utils

优点：配置简单，不依赖第三方软件

缺点：与主机在同网段，需要小心划分IP地址，需要有网段控制权，在生产环境中不易实现，不容易管理，兼容性不佳

- 使用 Open vSwitch实现跨主机容器连接

多层虚拟交换机，C语言开发，让大规模的网络自动化可以通过编程扩展，同时支持标准的管理接口和协议（NetFlow，sFlow，SPAN，RSPAN，CLI，LACP，802.1ag）

GRE：通用路由协议的封装

Open vSwitch基于网桥实现，位于网桥上层。

- 使用weave实现跨主机连接

建立一个虚拟的网路，用于将运行在不同主机的Docker容器连接起来 https://www.weave.works/
