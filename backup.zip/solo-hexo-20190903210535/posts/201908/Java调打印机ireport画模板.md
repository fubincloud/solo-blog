title: Java调打印机 ireport画模板
date: '2019-08-30 13:23:50'
updated: '2019-08-30 13:23:50'
tags: [ireport]
permalink: /articles/2019/08/30/1567142630466.html
---
1. 需要打印的字段打成jar包，参考PrinterFactory项目，然后引入ireport中

- 工具>选项>classpath引入业务jar

- 菜单栏：report datasources，指定PrinterFactory的工厂类和方法

- jrxml工作区：report query>java bean datasource>输入实体名，引入属性>add selected field(s)

- 主面板得到field字段，也可以自己手动添加(field存在的字段，实体类必须存在)

2. 使用ireport画模板

- 页面宽度问题：report inspector 调全局长宽属性

- table去掉边框：直接修改jrxml文件

- table绑定数据源：新建一个和field字段相同名字的datasources

- field list字段的field class使用：net.sf.jasperreports.engine.data.JRBeanCollectionDataSource

- 在Parameters下新建字段：同field字段名>绑定parameter Class：JREmptyDataSource

- 选中table组件>edit table datasource>绑定数据源(同field list字段名)

-  [一维码，二维码打印](https://blog.csdn.net/u010509052/article/details/53542462) ：使用zxing开源插件，使用image组件

- 一维码：image expression：com.google.zxing.client.j2se.MatrixToImageWriter.toBufferedImage( new com.google.zxing.oned.Code128Writer().encode( $F{orderNo},com.google.zxing.BarcodeFormat.CODE_128,200,80 ) )

- 二维码：com.google.zxing.client.j2se.MatrixToImageWriter.toBufferedImage(new com.google.zxing.qrcode.QRCodeWriter().encode($F{qrcodeUrl},com.google.zxing.BarcodeFormat.QR_CODE,100,100))

- 处理中文乱码：com.google.zxing.client.j2se.MatrixToImageWriter.toBufferedImage(newcom.google.zxing.qrcode.QRCodeWriter().encode(newString($P{c_plate_no}.getBytes("UTF-8"),"ISO-8859-1"),com.google.zxing.BarcodeFormat.QR_CODE,100,100))

  

```xml

<dependency>

<groupId>com.google.zxing</groupId>

<artifactId>core</artifactId>

<version>2.2</version>

</dependency>

<dependency>

<groupId>com.google.zxing</groupId>

<artifactId>javase</artifactId>

<version>2.2</version>

</dependency>

```

  

3. java调用ireport模板，参考类IreportPrinterDevice.java

- 引入maven的pom文件：ireport.xml


