title: Linux查看系统版本号
date: '2019-09-03 15:28:48'
updated: '2019-09-03 15:28:48'
tags: [Linux]
permalink: /articles/2019/09/03/1567495728498.html
---

```python
## 显示系统版本
cat /etc/redhat-release
cat /proc/version
uname -a
## 查看位数
getconf LONG_BIT 
file /bin/ls
```

![image.png](https://img.hacpai.com/file/2019/09/image-b66c56c3.png)

