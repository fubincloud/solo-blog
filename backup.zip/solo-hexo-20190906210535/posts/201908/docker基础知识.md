title: docker基础知识
date: '2019-08-18 15:05:12'
updated: '2019-08-27 00:09:26'
tags: [Docker]
permalink: /articles/2019/08/18/1566111912448.html
---
![](https://img.hacpai.com/bing/20190417.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## Docker资源

- [Docker练习教程](https://docker-curriculum.com/)

- [一个集成UNIX小程序的docker镜像:busybox](https://hub.docker.com/_/busybox/)

- [github](https://github.com/docker-library/busybox)

- docker部署webapp；后台运行，暴露端口 [外:内]

- docker镜像：版本指定

- 镜像分类：基础和子镜像，官方和用户镜像

- 创建自定义的镜像:[flask应用程序](https://github.com/prakhar1989/docker-curriculum.git)

- 通过Dockerfile构建自己的镜像

- Docker推送到云端共享给他人，使用公共Hub如[Docker官方Hub](https://hub.docker.com/) account:[`fubinh`](https://hub.docker.com/u/fubinh) ,[亚马逊AWS](https://aws.amazon.com/cn/ecr/)或者[自己创建私有镜像库](https://docs.docker.com/registry/deploying/)

- 多容器运行应用，[Python-Flask和Elasticsearch示例](https://github.com/prakhar1989/FoodTrucks)

- docker网路：桥接,创建自己的网络,隔离网络

- Docker Compose

- [Docker Machine](https://docs.docker.com/machine/) 在自己的计算机，云提供商和您自己的数据中心内创建Docker主机

- [Docker Compose](https://docs.docker.com/compose/) ：用于`定义和运行多容器Docker应用程序`的工具

- [Docker Swarm](https://docs.docker.com/swarm/) - Docker的本机群集解决方案

- [Kubernetes](https://kubernetes.io/) - Kubernetes是一个开源系统，用于自动化容器化应用程序的部署，扩展和管理。

- [Awesome Docker](https://github.com/veggiemonk/awesome-docker)

- [Docker课堂](https://training.play-with-docker.com/)

- 运维篇

- 研发篇

- [docker监控工具：lazydocker](https://github.com/jesseduffield/lazydocker)

```shell

## 前台运行

docker pull lazydocker

docker run -it -v /var/run/docker.sock:/var/run/docker.sock -v /opt/docker:/.config/jesseduffield/lazydocker lazyteam/lazydocker

```



- [官方文档](https://docs.docker.com/) ： 分为以下几大块内容

- 获取Docker

- 开始使用Docker

- 使用Docker进行开发

- 配置网络

- 管理应用程序数据

- 在生产中运行你的app

- Docker标准和合规性compliance

- Docker中的开源代码

- 文档归档(历史版本)


## Docker的基本组成

Docker客户端/守护进程：C/S架构 本地/远程

Docker Image 镜像 ： 容器的基石，层叠的只读文件系统 bootfs -> rootfs(ubuntu) -> add app , 联合加载

Docker Container 容器 ： 通过镜像启动，启动和执行阶段，写时复制

Docker Registry仓库 ： 共有，私有，Docker Hub

> Docker实际上是运行在Linux之上的技术，在windows和OS X中需要运行在docker定制的虚拟机上。

## 容器的基本操作

- 启动容器 docker run IMAGE command arg `docker run ubuntu echo "hello world"`

- 启动交互式容器 docker run -i -t ubuntu /bin/bash

	- -i --interactive=true\false

	- -t --tty=true/false

- 查看容器 docker ps [-a][-l][-q]

- docker inspect containerid/name 查看容器配置

- 自定义容器名字 docker run --name container新名字 -i -t ubuntu /bin/bash

- 重新启动和停止容器 docker start/stop -i containerName

	- 停止所有容器 `docker stop $(docker ps -a -q)`

- 删除停止的容器或所有容器 docker rm container / `$(docker ps -a -q)`


### 守护形式运行容器演示

- 运行容器 docker run -i -t ubuntu /bin/bash

- 退出容器内部/实际上在后台运行 ctrl +p 或 ctrl + q

- 重新进入容器 docker attach 容器id

- 真正退出容器 exit

- 守护式容器启动一般方法演示 docker run --name dc1 -d ubuntu /bin/sh -c "while true;do echo hello world ;sleep 1;done"

### 查看容器日志

docker logs -tf --tail 10 dc1

查看容器中的进程

docker top containerName

在运行中容器内部启动新进程

docker exec [-d][-i][-t] 容器名 [command][args]

停止守护式容器

docker stop 容器名

docker kill 容器名

## 镜像操作

docker images  [-a --all] [-f filter] [--no-trunc imageid不截断][-q --quiet 只显示id]
	- repository,tag,image id,created,大小
	- <none>中间层镜像
查看镜像详细信息：docker inspect  imageid/仓库+tag
删除镜像 docker rmi  imageid/仓库+tag
删除所有镜像 docker rmi $(docker images -q  ubuntu)

查找镜像
	- Docker Hub
	- docker search  imagesName [--automated=false][--no-trunc][-s --stars 最低star数]
拉取镜像
	- docker pull  仓库+tag [不指定则下载lastest]

> 国内docker镜像服务器加速镜像下载
使用 --registry-mirror选项,修改完毕后重启docker守护进程 service docker restart
	- /etc/default/docker 添加 DOCKER_OPTS = "--registry-mirror=http://www.daocloud.io"
推送镜像
	- docker push imageName:tag


## 构建镜像

- 通过容器构建 ：docker commit  [-a --author][-m --message] [-p --pause=true] 容器名 
	- 把应用打成新的镜像  `docker commit -a "fubinh" -m "nginx web server test"  nginx_web_test fubinh/nginx_web_test`
	- 用新镜像启动容器：`docker run -d --name nginx_web -p 80 fubinh/nginx_web_test nginx -g "daemon off;"`


- 通过Dockerfile构建镜像 ： docker build --force-rm= false --no-cache=false --pull=false [-q,--quiet=false],--rm=true,[-t,--tag="ImageName"]
```python
FROM centos
MAINTAINER fubinh "fubincloud@gmail.com"
RUN rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
RUN yum install -y nginx
EXPOSE 80
```
开始根据Dockerfile文件构建 ：`docker build -t='fubinh/nginx_web_test2'  .`    注意这里有一个点，代表Dockerfile文件在当前文件夹


## Docker的C/S模式 - Remote API

- https://docs.docker.com/develop/sdk/

连接方式

- unix:///var/run/docker.sock

- tcp://host:port

- fd://socketfd

> 客户端和服务端可以部署在不同的机器上，可以通过以上三种方式调用服务端接口

## Docker守护进程配置

启动选项

	运行相关：[-D --debug][-e --exec-driver="native"][-g --graph="/var/lib/docker"]
	
	服务器连接相关 [-G ,-H]...
	
	存储相关 [-S ]...
	
	Registry相关
	
	网络设置相关
	
	docker启动配置文件 ：linux[/etc/defaults/docker]

## Docker的远程访问

Docker客户端和服务端部署在两台机器上

	-H 选项
	
	DOCKER_HOST环境变量简化远程访问配置

## Dockerfile 指令

- FROM 基础镜像

- MAINTAINER 维护者

- RUN 运行指令 ，`镜像构建过程中`执行

- EXPOSE 暴露端口

- CMD `容器运行时`执行的指令（会覆盖我们在命令行docker run指定的命令）

- exec模式 CMD[ "executable","param1","param2"]

- shell 模式 CMD command param1 param2

- CMD["param1","param2"] 作为ENTRYPOINT指令默认参数, 启动容器时后面带的命令会把cmd命令覆盖

- ENTRYPOINT ：和cmd唯一区别是不会覆盖docker run的指定命令,`只有最后一条生效`，启动容器后面的命令覆盖不了entrypoint带的命令，可以在docker run 后面带--entrypoint参数覆盖

- ADD [src dest] 文件和目录复制到使用Dockerfile构建的镜像中,包含了`tar解压功能`,可以带远程`链接地址`

- COPY 单纯复制，推荐使用COPY而不是ADD

- VOLUME["/data"] 可以存在于一个或者多个容器的特定目录，这个目录可以绕过联合文件系统，提供共享数据和数据持久化的功能

- WORKDIR /path/to/workdir 从镜像创建一个新容器时，在容器内部设置工作目录，cmd和entrypoint指定的命令都会在这个目录下执行，通常使用绝对路径，如果使用相对路径，会传递下去。

- ENV key=value 环境变量，构建和运行过程中有效

- USER daemon 以什么用户来运行,默认root用户

- USER user / uid / user:group / uid:gid / user:gid / uid:group

- ONBUILD 镜像触发器 ，当一个镜像被其他镜像作为基础镜像时执行，在构建过程中插入指令 ，比如复制宿主机上的页面替代nginx默认页面，当构建新的镜像时，这个替换才会生效。

## 镜像的构建过程 
	- 使用缓存和不使用缓存(--no-cache)
	- 中间层镜像调试
	- 查看构建过程 docker history images

## Docker 网络

### 基础

- docker0 网桥 属于 ISO七层模型中的数据链路层

- 修改docker0的ip ：ifconfig docker0 192.168.21.110 netmask 255.255.255.0

- 自定义虚拟网桥

### 容器互联

- 允许所有容器互联 默认 --icc=true

- --link container:别名 启动时docker会自动修改容器的ip地址和hosts文件的映射

- 拒绝容器间的连接 --icc=false (全部拒绝)

- 允许特定的容器间的连接 --icc=false --iptables=true（控制网络访问的组件，配置了--link的可以访问）

iptables -L -n

### 容器与外部网络连接

--ip_forward=true ： 是否允许转发流量

iptables ：与Linux内核集成的包过滤防火墙系统 表table。链filter（input，forward，output），规则rule

允许端口映射访问

限制IP访问容器

> 学习iptables的设置

## 容器的数据管理

### 数据卷

变化的数据需要持久化，数据需要在容器间共享。可以绕过联合文件系统UFS

添加数据卷：docker run -v ~/container_data:/data -it ubuntu /bin/bash

为数据卷添加只读权限：docker run -v ~/container_data【本地宿主机目录】:/data【容器内目录】:ro -it ubuntu /bin/bash

Dockerfile创建数据卷： VOLUME["/data/d1"."/data/d2"]，本地的映射目录由docker自动创建，使用docker inspect containerid 查看，相同dockerfile创建的不同容器数据卷是不同的

### 数据卷容器

实现数据的共享：命名的容器挂在数据卷，其他容器通过挂载这个容器实现数据共享，挂载数据卷的容器，就叫做数据卷容器。

docker run --volumes-from 挂载了数据卷的容器名

查看配置过滤信息：docker inspect --format="{{.Volumes}}" 容器名

如果数据卷容器删除了，不影响其他容器数据的使用，容器数据卷挂载可以传递。

>如果一个数据卷还在被容器使用，那么他就会一直存在。

### 数据卷的备份和还原

备份方法：新建一个用于数据备份的容器

docker run --volumes-from 容器名 -v /backup[本地目录]:/backup[容器目录] --name containerName[备份容器名] ubuntu[镜像] tar cvf /backup/dvt5.tar[压缩后的名字] /datavolume1[需要备份的目录]

还原和备份的思路一致，把压缩命令替换成解压缩命令

## 容器的跨主机连接

- 使用网桥实现跨主机容器连接

安装网桥管理工具 bridge-utils

优点：配置简单，不依赖第三方软件

缺点：与主机在同网段，需要小心划分IP地址，需要有网段控制权，在生产环境中不易实现，不容易管理，兼容性不佳

- 使用 Open vSwitch实现跨主机容器连接

多层虚拟交换机，C语言开发，让大规模的网络自动化可以通过编程扩展，同时支持标准的管理接口和协议（NetFlow，sFlow，SPAN，RSPAN，CLI，LACP，802.1ag）

GRE：通用路由协议的封装

Open vSwitch基于网桥实现，位于网桥上层。

- 使用weave实现跨主机连接

建立一个虚拟的网路，用于将运行在不同主机的Docker容器连接起来 https://www.weave.works/

## 搭建私有仓库
1. 下载docker registry服务
docker pull registry
2. 启动，端口5000
docker run -d -p 5000:5000 --name registry registry
3. 前端界面
```
sudo docker run \
  -d \
  -e ENV_DOCKER_REGISTRY_HOST=localhost \
  -e ENV_DOCKER_REGISTRY_PORT=8080 \
  -p 8080:80 \
  konradkleine/docker-registry-frontend:v2
```
>参考 ：[手把手教你搭建Docker Registry私服](https://segmentfault.com/a/1190000015108428)


## # [使用Dockerfile构建Centos7镜像/php镜像/wordpress](http://fubincloud.cn/articles/2019/08/24/1566662006622.html)

本实验在OSX Parallels Desktop Centos7中验证,环境准备遇到的问题：
1.[不能root用户登录，参考](https://blog.csdn.net/LCYong_/article/details/60466601) ,  [sudo su](https://linux.cn/article-8404-1.html)
2.[yum安装出现/var/run/yum.pid已被占用，删除该文件即可，参考](https://blog.csdn.net/LCYong_/article/details/60466601)
3.[安装git 参考 ](https://git-scm.com/book/zh/v1/%E8%B5%B7%E6%AD%A5-%E5%AE%89%E8%A3%85-Git)
4.克隆资源 [https://gitee.com/dockerf/docker-training](https://gitee.com/dockerf/docker-training)  
https://csphere.cn/
5.[Centos Docker安装](https://www.runoob.com/docker/centos-docker-install.html)

>Docker体积小的原因 ：不包含父镜像的大小 

- Centos
- php-fm
- mysql
- wordpress
  

## 操作步骤
> 查看命令使用方式 docker help build
```
## 构建基础镜像
## docker build -t registry_url/namespace/fubin/centos:7.1  ./path
docker build -t csphere/centos:7.1 .
## 运行  端口 -P容器重启后宿主机端口会发生变化和 -p端口不变
docker run -d -p 2222:22 --name base  csphere/centos:7.1 


## 构建中间镜像 php-fm
docker build -t csphere/php-fpm:5.4 .
## 
docker run -d -p 8080:80  --name website  csphere/php-fpm:5.4
## 检查php环境
http://127.0.0.1:8080/info.php
## 进入交互式模式 attach会挂掉
docker exec -it  website  /bin/bash
## supervisor 工具查看进程状态
supervisorctl

## 构建中间镜像mysql，如果这个镜像想包含php的功能，FROM则可以使用php-fm镜像
docker build -t csphere/mysql:5.5 .
## start脚本 set -e 第一条脚本执行出错，则不会继续执行下面的命令

## 启动mysql5.5
docker run -d -p 3307:3306 --name dbserver scphere/mysql:5.5
##进入容器
docker exec -it dbserver /bin/bash
## 挂载volmue
docker run -d -p 3307:3306 -v ~/Documents/Projects/docker/docker-training/mysql/data:/var/lib/mysql --name dbserver csphere/mysql:5.5

## 构建服务wordpress
.dockerignore  忽略某文件
## 使用php-fm当作父镜像，ONBUILD指令起作用，把php文件拷贝到/app目录中
docker build -t csphere/wordpress:4.2 ./wordpress
## 启动 wordpress
docker run -d -p 80:80 --name wordpress -e WORDPRESS_DB_HOST=127.0.0.1 -e WORDPRESS_DB_USER=admin -e WORDPRESS_DB_PASSWORD=csphere2015 csphere/wordpress:4.2 
```

## 在Docker中部署静态网站

- 设置容器的端口映射

	- 大写[-P] --publish-all=true `docker run -P -i -t ubuntu /bin/bash`

 	- 小写[-p] --publish=[]

- 指定容器端口 `docker run -p 80 -i -t ubuntu /bin/bash`

- 指定主机端口和容器端口 `docker run -p 8080:80 -i -t ubuntu /bin/bash`

- 指定ip和容器端口 `docker run -p 0.0.0.0:80 -i -t ubuntu /bin/bash`

- 指定ip宿主机端口，容器端口`docker run -p 0.0.0.0:8080:80 -i -t ubuntu /bin/bash`

- 拉取centos容器 docker search centos ，docker pull centos

- 启动容器并把端口映射为9999：`docker run -i -t -d -p 9999:80 --name web centos /bin/bash`

- 安装必要软件，如wget,curl `yum install -y wget `

- 安装nginx : yum方法安装无法安装成功，需要安装nginx源 `yum install -y nginx`

- `rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm`

- yum源的资源路径在`/etc/yum/repos.d/nginx.repo`

- 外网访问http://localhost:9999,容器内访问http:://localhost:80

- 其他容器访问，通过docker inspect查看容器的ip ，端口任然使用80


> 附录

以下是Nginx的默认路径：

(1) Nginx配置路径：/etc/nginx/  
(2) PID目录：/var/run/[nginx.pid](https://www.centos.bz/tag/nginx-pid/)  
(3) 错误日志：/var/log/nginx/[error](https://www.centos.bz/tag/error/).log  
(4) 访问日志：/var/log/nginx/access.log  
(5) 默认站点目录：/usr/share/nginx/html

以下是Nginx常用命令
- 启动：nginx
- 测试配置是否正确 nginx -t
- 优雅重启 nginx -s reload
- 查看nginx进程 ps -ef | grep nginx
- 停止 nginx -s stop 或 kill -9 pid



