title: BCompare 4 Windows激活方法【试用期30天重置】
date: '2019-08-30 11:36:08'
updated: '2019-08-30 11:51:16'
tags: [BCompare]
permalink: /articles/2019/08/30/1567136168529.html
---
## 激活方法

1.修改C:\Program Files\Beyond Compare 4\BCUnrar.dll ,这个文件重命名或者直接删除，则会新增30天试用期，再次打开提示还有28天试用期。

2.一劳永逸，修改注册表

    1)在搜索栏中输入 regedit   ，打开注册表

    2)删除项目：计算机\HKEY_CURRENT_USER\Software\Scooter Software\Beyond Compare 4\CacheId


原文链接：https://blog.csdn.net/lisheng19870305/article/details/85112900
