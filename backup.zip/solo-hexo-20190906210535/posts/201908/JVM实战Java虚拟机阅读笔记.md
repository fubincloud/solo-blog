title: JVM：《实战Java虚拟机》阅读笔记
date: '2019-08-17 20:50:15'
updated: '2019-08-31 21:54:38'
tags: [JVM]
permalink: /articles/2019/08/17/1566046215170.html
---

#  Java历史

依托于Java虚拟机的语言

	- Java
	
	- Ckojure - Kisp的方言
	
	- Jython - 将python运行在JVM上
	
	- Groovy - JVM上的脚本语言
	
	- Scala - 专注于高并发解决方案
	
	- Kotlin - 安卓开发首选

Java发展史

	- 跨平台系统，Oak
	
	- Sun发布Java和HotJava产品
	
	- JDK1.0，运行环境和开发环境，核心api，用户界面api，发布技术，jvm，使用Classic虚拟机解释执行
	
	- JDK1.1 AWT，内部类，JDBC，RMI，反射，sun获得hotspot虚拟机
	
	- Jython创造，目前已经可以运行Django了
	
	- JDK1.2 兼容智能卡和小型消费设备，大型服务器系统，发布JSP/Servlet规范，Java分裂为J2EE,J2SE，J2ME，解释和编译混合执行
	
	- JDK1.3 Hotspot成为Java默认虚拟机
	
	- JDK1.4 Classic虚拟机淘汰
	
	- JDK1.5 改名5.0，范型，注解，自动装箱拆箱，枚举，可变长参数，增强foreach
	
	- JDK1.6 开源OpenJDK，Hotspot是它的默认虚拟机
	
	- 新语言Clojure出现
	
	- Oracle收购BEA，得到JRockit虚拟机
	
	- Scala：Twitter迁移大部分Ruby服务到Scala
	
	- Oracle收购Sun，准备规划整合Hotspot和JRockit虚拟机
	
	- JDK1.7发布，新垃圾回收器G1，64位压缩指针，NIO2.0，增加invokedynamic指令
	
	- JDK1.8 Lambda表达式
	
	- JDK1.9 Java模块化

  [Java语言规范](https://docs.oracle.com/javase/specs/)

- 数字的表示

```java

//JDK1.7允许在数字中加加入下划线分割
int a = 0372;
int b = 0xDada_Cafe;
int c = 0x00_FF__00_FF;
long la = 01;
long lb = 0777L;
long lc = 0x100000000L;
long ld = 2_147_483_648L;
long le = 0xC0B0L;
float fa = 1e1f;
float fb = 2.f;
float fc = .3f;
float fd = 3.14f;
float fe = 6.022137e+23f;
double da = 1e1;
double db = 2.;
double dc = .3;
double dd = 0.0;
double de = 1e-9d;
double df = 1e137;
```

- 数据类型

	- 原始

		- 数字型：（byte 8bit ，short 16bit ，int 32bit，long 64bit）有符号，char 16bit 无符号，float 32bit，double 64bit

		- 布尔型：boolean ：true，false

	- 引用

  [Java虚拟机规范](https://docs.oracle.com/javase/specs/index.html)

- 特性

	- 跨平台
	
	- 优秀的垃圾回收器
	
	- 可靠的即时编译器

- 内容

	- 虚拟机内部结构
	
	- 虚拟机执行的字节码类型和功能
	
	- Class文件结构
	
	- 类的装载，连接，初始化

- 整数在虚拟机中的表示

	- 在计算机中整数用补码表示，虚拟机也是
	
		- 概念：原码，反码，补码
	
			- 原码：1符号位 + 其余二进制数
			
			- 反码：符号位不变，其余取反
			
			- 补码：负数补码= 反码+1 ，正数补码= 原码

		- 补码好处：
			
			- 统一数字0的表示，原码很难确定无符号数字0
			
			- 简化整数的加减计算，正负数计算统一成加法。

```java

//-10在虚拟机的表示

// 0x80000000 为符号为1，其余是0的32位数字，得到i位数字，并把除i之外的其他位数设置为0，然后把i移到最右输出

int d = -10;

for(int i = 0; i<32;i++){

int t = (d & 0x80000000 >>> i) >>> (31-i);

System.out.print(t);

}

```

- 浮点型在虚拟机的表示

	- IEEE754定义的浮点数格式

		- 三部分：符号位 + 指数位 + 尾数位
		
		- float 32bit ：1符号位 + 8指数位 + 23尾数位 `s eeeeeeee mmmmmmmmmmmmmmmmmmmmmmm`

	- 浮点数-5 `1 10000001 0100000000000000000000`

		- 符号为 1 ，负数
	
		- 指数位 129
		
		- 尾数位(`实际上是24位`) ： e不全位0，前面加1=`1`0100000000000000000000 ,全为0，则附加0
	

	- 表示特殊数字
	
		- 正无穷
		
		- 负无穷
		
		- NaN
		
		- 最大浮点数
		
		- 最小规范化正浮点数
		
		- 最小正浮点数
		
		- 0
	

 编译和调试虚拟机

- 作用

	- 得到一个debug版本，支持更多虚拟机参数
	
	- 用于虚拟机代码单步调试

- [centos7构建jdk8](http://hg.openjdk.java.net/jdk8u/jdk8u/raw-file/tip/README-builds.html)

	- 安装jdk版本控制系统[mercurial变幻莫测](https://www.mercurial-scm.org/release/centos7/RPMS/x86_64/),[download](https://mercurial.selenic.com/wiki/Download#Windows); centos :`yum install mercurial`

	- OSX安装:`brew install mercurial`

- 拉取源码：

```markdown

hg clone http://hg.openjdk.java.net/jdk8/jdk8 YourOpenJDK

cd YourOpenJDK

bash ./get_source.sh

```

# JVM基本结构

![内存结构1.png](https://img.hacpai.com/file/2019/08/内存结构1-575f6394.png)



- Java虚拟机基本结构

- 角色：字节码执行引擎，垃圾回收系统，`方法区，Java堆，直接内存`[共享]，类加载子系统，`PC寄存器(计数器)，本地方法栈，Java栈`[私有]

- 垃圾回收的工作重点：方法区，Java堆，直接内存

- 一个Java线程对应一个java栈

- 参数

- 程序参数：应用程序使用

- 虚拟机参数：虚拟机使用

- Java堆的结构

- 新生代 ： young

- from

- to

- eden ：对象创建的地方

- -------> young转换到tenured:`对象年龄`

- 老生代：tenured

```

Java  [-options]虚拟机参数   class[java类]  args[主函数的参数]

```

获取jvm的最大内存 `-Xms32M`

System.out.println(Runtime.getRuntime().maxMemory()/1000/1000 + "M");

  

指定栈的最大空间 `-Xss256K`  ,影响栈深度：1.参数个数 2.局部变量个数

局部变量槽位复用:b会复用a的槽位

```

public static void localvar2(){

    {

        int a = 0 ;

        System.out.println(a);

    }

    int b = 0;

}

```

**局部变量的垃圾回收的根节点**

**-XX:PrintGC  打印垃圾回收日志**

**栈上分配 ： 逃逸分析（成员变量还是局部变量）**

**-server : server模式下运行java程序**

**-XX:+DoEscapeAnalysis  逃逸分析 ，server模式下才能进行逃逸分析**

**-XX:+EliminateAllocations 标量替换**

  

java 1.6，1.7方法区 

-XX:PermSize  初始值

-XX:MaxPermSize 默认64M

java1.8 元数据区

-XX:MaxMetaspaceSize ,是一块堆外的直接内存


# 常用Jvm参数

  

> 跟踪垃圾回收

  

-XX:PrintGC 

-XX:+PrintGCDetails  更详细的信息，新生代GC还是老生代GC，永久区的GC，gc的时间

```

Heap

PSYoungGen      total 76288K, used 1311K [0x000000076ab00000, 0x0000000770000000, 0x00000007c0000000)

  eden space 65536K, 2% used [0x000000076ab00000,0x000000076ac47c58,0x000000076eb00000)

  from space 10752K, 0% used [0x000000076f580000,0x000000076f580000,0x0000000770000000)

  to   space 10752K, 0% used [0x000000076eb00000,0x000000076eb00000,0x000000076f580000)

ParOldGen       total 175104K, used 478K [0x00000006c0000000, 0x00000006cab00000, 0x000000076ab00000)

  object space 175104K, 0% used [0x00000006c0000000,0x00000006c0077b80,0x00000006cab00000)

Metaspace       used 2777K, capacity 4486K, committed 4864K, reserved 1056768K

  class space    used 299K, capacity 386K, committed 512K, reserved 1048576K

```

-XX:+PrintHeapAtGC : 每次gc前后分别打印堆信息

-XX:+PrintGCTimeStamps 分析gc发生的时间，在每次gc时额外输出gc发生的时间

-XX:+PrintGCApplicationConcurrentTime  由于gc会引起应用程序停顿，特别关注app的执行时间

-XX:+PrintGCApplicationStoppedTime 停顿时间

-XX:+PrintReferenceGC 跟踪系统软引用，弱引用，Finallize队列

-Xloggc:log/gc/log  默认gc日志控制台输出，该参数指定写入日志文件

  

> 类加载和卸载的跟踪

  

-verbose:class 跟踪类的加载和卸载 ，最后一次加载的类没有机会被卸载

-XX:TraceClassLoading 单独跟踪类的加载

-XX:TraceClassUnloading 跟踪类的卸载

-XX:+PrintClassHistogram 运行时打印和查看系统类的分布情况

  

> 系统参数查看

  

-XX:+PrintVMOptions 打印虚拟机接收到的命令行显示参数

-XX:+PrintCommandLineFlags  包含显示指定和虚拟机自行设置的参数

-XX:+PrintFlagsFinal 打印系统所有的参数值

  

> 让性能飞起来 ：堆的配置参数

  

-Xms 初始堆的大小

-Xmx 最大堆

实际最大可用内存（与-Xmx存在偏差） = -Xmx最大内存 - from区的大小 （垃圾回收空间换时间的算法）

设置-Xms和-Xmx大小相等，可以减少gc的次数

  

新生代配置

-XX:SurvivsorRatio 设置新生代eden和from/to的比例关系 ： eden/from = eden/to

-Xmn 年轻代大小

基本配置策略：尽可能将对象预留在新生代，减少老年代GC的次数
```
## 其他参数
（1）最高优先级：  -XX:NewSize=1024m和-XX:MaxNewSize=1024m   
（2）次高优先级：  -Xmn1024m  （默认等效效果是：-XX:NewSize==-XX:MaxNewSize==1024m）   
（3）最低优先级：-XX:NewRatio=2
```

-XX:NewRatio 新生代和老年代的比例


>  堆溢出处理

  

-XX:HeapDumpOnOutOfMemoryError 在内存溢出时导出整个堆信息

-XX:HeapDumpPath=./a.dump  导出堆信息的路径

-XX:OnOutOfMemoryError=脚本文件  在内存溢出时执行脚本（可以是导出java线程信息）

  

> 非堆内存的参数配置

  

方法区

jdk1.6和1.7 

-XX:PermSize

-XX:MaxPermSize 

jdk1.8

-XX:MaxMetaspaceSize

  

栈

-Xss

  

直接内存

-XX:MaxDirectMemorySize 最大可用直接内存,默认值为最大堆空间

直接内存适合申请次数少，访问较为频繁的场合，如果内存空间本身需要频繁申请，并不适合使用直接内存。

  

  

> 虚拟机的工作模式 :Server 和Client

  

-client

-server  : 64位操作系统更倾向于使用server模式

```

java -version  

java -client -version

java -server -version 

```
两种模式下，可使用-XX:PrintFlagsFinal对比两种模式下参数的差异

# 理论基础：垃圾回收算法和对gc耗时的影响


引用计数法 ：Java虚拟机并未采用这种算法

缺点：1.对象的循环引用 2.伴随加法和减法操作，有一定的性能开销

  

-可达对象

-不可达对象 ： 通过根对象进行引用搜索

  

复制算法：通常存活对象很少，这个算法效率高，也没有空间碎片，但是内存折半

  

标记清除法：会产生空间碎片

  

标记压缩法：老年代存活对象多，复制算法不划算，所以使用标记清除算法的优化版 ， 会在标记后把存活对象压到一端。等同于标记后再进行一次碎片整理。也加标记清除压缩算法

  

分代，分区的思想

新生代使用类复制算法的思想。from和to区

分代算法的叫法是上面算法的综合运用，使用了上面算法的各自优势。  

卡表：记录新生代对象引用在老年代是否使用，用于加快新生代的回收速度。  

  

分区算法：把堆分为多个不同的小区间，每个区间独立回收。减少大块堆gc的停顿时间。

  

  

判断对象可达性的依据

1.可触及：从根节点开始，对象可达

2.可复活：对象引用已释放，但有可能在finalize函数中复活

3.不可触及：对象finalize函数被调用，并且没复活，finalize只会被调用一次（不要再使用这个函数了），资源释放推荐try-catch-finally

  

  

引用和可触及性的强度

1.引用级别：强，软，弱，虚,  后面三种对象在一定场景下是可以被回收的

软引用：在堆空间不足时，会被回收，所以这种不会引起内存溢出

弱引用 ：发现就被回收，取决于下一次垃圾回收的时机

> 很适合保存缓存数据

虚引用 ：用于跟踪垃圾回收的过程

  

  

STW：Stop-The-World 垃圾回收的停顿现象

使用超大的新生代，from和to区，会导致复制算法复制大量的对象，会很大程度上延长gc的时间


# 垃圾回收器

垃圾收集算法只是理论基础，垃圾收集器才是项目中的最佳实践。

##  垃圾收集器种类及参数设置

```
-XX:+UseSerialGC  新生代和老年代都使用串行收集器
## ParNew 指定线程数量 -XX:ParallelGCThreads,默认值cpu< 8个=cpu数，大于8个（3+((5*CPU个数)/8)）

-XX:+UseParNewGC 新生代ParNew(多线程的串行收集器)收集器，老年代使用串行收集器

## ParallelGC注重吞吐量，支持自适应的GC调节策略
## 控制吞吐量的参数：-XX:MaxGCPauseMillis=最大收集停顿时间，-XX:GCTimeRatio=吞吐量 n默认=99则是使用1/(1+n)的时间来做垃圾回收
## -XX:UseAdaptiveSizePolicy 打开自适应GC策略
-XX:+UseParallelGC   新声代使用parallelGC收集器，老年代使用串行收集器
## ParallelOldGC 作用于老年代的并行收集器，也是注重吞吐量的，jdk1.6才能使用
-XX:+UseParallelOldGC  新生代使用ParallelGC收集器，老年代使用ParallelOldGC收集器

## CMS关注系统停顿时间
## 步骤 ： 3标记 2清理 1重置 
## 标记根对象（初始标记） -> 标记所有对象（并发标记） -> 清理前准备以及控制停顿时间（预清理） -> 修正并发标记数据（重新标记） -> 清理垃圾（并发清理） -> 重置（并发重置）
## 并发xx ，可以和用户线程一起执行
-XX:-CMSPrecleaningEnabled 关闭预清理
## （设置的并发线程数+3）/4 =  设置4个并发线程意味着只有一个垃圾收集的并发线程
-XX:+UseConcMarkSweepGC 新生代使用ParNew回收器，老年代使用CMS
-XX:+CMSInitiatingOccupancyFraction 回收阀值，默认68，老年代使用率达到68%时会执行CMS回收。
-XX:+UseCMSCompactAtFullCollection CMS会产生垃圾碎片，这个参数使用多少次CMS回收后，会进行内存压缩。
## CMS回收Perm区
-XX:+CMSClassUnloadingEnabled

## G1回收器 Garbage-First JDK1.7
# G1属于分代，结构上不要求各个区域连续，使用了分区算法
## 四个阶段 ：新生代GC 并发标记周期 混合收集 FullGC
-XX:UseG1GC  开启G1参数
-XX:MaxGCParseMillis 最大停顿时间 
-XX:ParallelGCThreads  工作线程数量
-XX:InitiatingHeapOccupancyPercent 比例达到比例，触发并发标记周期
-XX:+DisableExplicitGC 禁止显示触发FullGC
-XX:+ExplicitGCInvokesConcurrent  CMS和G1在FullGC时，使用System.gc()才会并发执行

```
