title: Solo 博客系统折腾记录
date: '2019-08-17 18:26:20'
updated: '2019-08-27 14:28:28'
tags: [Solo]
permalink: /articles/2019/08/17/1566037580555.html
---
# 数据库篇

```

create database solo default charset utf8mb4 collate utf8mb4_general_ci;


#启动
docker run --name mysql -p 3306:3306 -e MYSQL_ROOT_PASSWORD=Lzslov123! -d mysql
#进入容器
docker exec -it mysql bash
#登录mysql
mysql -u root -p
ALTER USER 'root'@'localhost' IDENTIFIED BY 'Lzslov123!';

#添加远程登录用户
CREATE USER 'liaozesong'@'%' IDENTIFIED WITH mysql_native_password BY 'Lzslov123!';
GRANT ALL PRIVILEGES ON *.* TO 'liaozesong'@'%';


-- 启动solo服务
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="xxxx" \
    --env JDBC_PASSWORD="xxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    b3log/solo --listen_port=80 --server_scheme=http --server_host=域名 --server_port=80

```


  
文件上传下载工具 ：xshell 下的rz sz  
https://blog.51cto.com/oldboy/588592  
  
  
Docker下的数据库备份：  
  
https://blog.csdn.net/MR1269427885/article/details/82978311  
  
```  
docker exec -i solodb bash <<'EOF'  
  
mkdir ~/$(date +%Y%m%d)  
  
## 备份指定数据库  
mysqldump --databases solo  -u用户名 -p密码 > /root/$(date +%Y%m%d)/solodb_$(date +%Y%m%d_%H%M%S).sql  
##mysqldump -u用户名 -p密码 > ~/$(date +%Y%m%d)/solodb_$(date +%Y%m%d_%H%M%S).sql  
  
# 备份所有数据库  
## mysqldump --no-defaults --events --all-databases -uroot -padmin > /backup/mysql/$(date +%Y%m%d)/all_$(date +%Y%m%d_%H%M%S).sql  
  
exit  
  
EOF  
  
docker  cp -a  solodb:/root/$(date +%Y%m%d)   /root/info/data/  
  
```

crontab定时任务 
```
## 定时任务
crontab -e

# 每天下午一点执行脚本 
0 13 * * * bash /backup/mysql.sh

##重启crond
service crond restart
```

### 服务器复制文件到本地

```
#!/bin/bash

filename=`date -v -0d +%Y-%m-%d`
## 远程拷贝
scp -r root@IP:服务器路径  ./${filename}
## 压缩
zip -r ${filename}.zip ${filename}
```

# 配置Blog二级域名篇

初步想法： 
使用 blog.fubincloud.cn 作为博客系统的域名
www.fubincloud.cn 单独做一个静态导航页面，部署在nginx中，nginx还可以放其他静态页面，比如极客时间的教程资源，方便随时浏览。



