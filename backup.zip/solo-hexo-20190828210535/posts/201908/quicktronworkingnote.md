title: quicktron working note
date: '2019-08-17 21:34:54'
updated: '2019-08-28 15:58:09'
tags: [work]
permalink: /articles/2019/08/17/1566048893918.html
---
![](https://img.hacpai.com/bing/20180326.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 


##  jdwp远程调试如何操作 

（1）远程程序的配置在javaArgs加入参数-Xdebug -Xrunjdwp:transport=dt_socket,suspend=n,server=y,address=5555在快仓的后台（manager-ng）中，则是编辑wallemanagerd，在javaArgs加入上述参数。

（2）ecplise配置菜单：Debug -》 Debug confeguration弹窗：Remote Java Application双击Remote Java Application会生成监听当前模块的类应用Host：远程程序的ip地址Port：远程javaArgs公开的端口。单击Debug则开始远程监听调试，需要设置断点来看变量。

## 线上出现CPU 100%怎么办？


1.top查看占用cpu高的进程
2.top -p pid -H 查看进程中的线程
3.jstack -l -F pid 查看2步骤中列出来的进程中线程栈，拿到一些线程信息
4.如何检索：进程pid和线程中的对应关系，需要把2步骤的pid转化为十六进制
5.在线程栈文件中搜索 ：`cat jstack.dump | grep "nid=0x779" -C 10`
6.GC问题调参数，其他问题再分析
7.推荐诊断开源工具 ：[Arthas](https://github.com/alibaba/arthas/blob/master/site/src/site/sphinx/index.md)

内存占用前五的进程：`ps auxw | head -1 ; ps auxw | sort -rn -k4 | head -5`
cpu占用前五的进程：`ps auxw | head -1 ; ps auxw | sort -rn -k3 |head -3`

